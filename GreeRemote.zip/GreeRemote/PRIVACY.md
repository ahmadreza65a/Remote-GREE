# Privacy Policy — Split Remote

Split Remote is an infrared (IR) remote control for split air conditioners.

- The app does not collect, store on any server, or share any personal data.
- The app has no internet access and contains no ads or analytics.
- The only permission used is TRANSMIT_IR, to send infrared commands from the phone's IR blaster.
- Your settings (temperature, mode, etc.) are saved only on your own device and are removed when you uninstall the app.

Gree is a trademark of its respective owner. This app is not affiliated with or endorsed by Gree.

Contact: (your email)
