package ir.remote.gree;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * Resolution-independent line icons drawn on a 24x24 grid centred at (0,0).
 * No image resources are needed, so the icons stay sharp on every screen.
 */
public class Icon extends Drawable {

    public static final int POWER = 0, SNOW = 1, SUN = 2, DROP = 3, FAN = 4, AUTO = 5, BOLT = 6,
            MOON = 7, BULB = 8, WIND = 9, LEAF = 10, THERMO = 11, CLOCK = 12, SCREEN = 13, GEAR = 14,
            SIGNAL = 15, PLUS = 16, MINUS = 17, PAUSE = 18, ARROW = 19, ARC = 20, BARS = 21, INFO = 22;

    private final int type;
    private int color;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    // Extra parameters for direction icons
    private float a1, a2, ox, oy;
    private boolean unitBar;
    private int level;

    public Icon(int type, int color) {
        this.type = type;
        this.color = color;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
    }

    /** Air-flow arrow leaving the indoor unit at the given angle (0 = right, 90 = down). */
    public static Icon arrow(int color, float angle, boolean vertical) {
        Icon i = new Icon(ARROW, color);
        i.a1 = angle;
        i.ox = vertical ? -6 : 0;
        i.oy = -6;
        i.unitBar = true;
        return i;
    }

    /** Swinging air-flow between two angles. */
    public static Icon arc(int color, float from, float to, boolean vertical) {
        Icon i = new Icon(ARC, color);
        i.a1 = from;
        i.a2 = to;
        i.ox = vertical ? -6 : 0;
        i.oy = -6;
        i.unitBar = true;
        return i;
    }

    /** Fan speed bars (1..3). */
    public static Icon bars(int color, int level) {
        Icon i = new Icon(BARS, color);
        i.level = level;
        return i;
    }

    public void setColor(int c) {
        if (c != color) {
            color = c;
            invalidateSelf();
        }
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        float s = Math.min(b.width(), b.height()) / 24f;
        c.save();
        c.translate(b.exactCenterX(), b.exactCenterY());
        c.scale(s, s);
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        Path path = new Path();

        switch (type) {
            case POWER:
                c.drawArc(new RectF(-8, -7, 8, 9), -55, 290, false, p);
                c.drawLine(0, -10, 0, -1, p);
                break;

            case SNOW:
                for (int k = 0; k < 3; k++) {
                    c.save();
                    c.rotate(k * 60);
                    c.drawLine(0, -10, 0, 10, p);
                    for (int sgn = -1; sgn <= 1; sgn += 2) {
                        c.drawLine(0, sgn * 6.5f, -3, sgn * 9.5f, p);
                        c.drawLine(0, sgn * 6.5f, 3, sgn * 9.5f, p);
                    }
                    c.restore();
                }
                break;

            case SUN:
                c.drawCircle(0, 0, 4.5f, p);
                for (int k = 0; k < 8; k++) {
                    double a = Math.toRadians(k * 45);
                    c.drawLine((float) (7.5 * Math.cos(a)), (float) (7.5 * Math.sin(a)),
                            (float) (10.5 * Math.cos(a)), (float) (10.5 * Math.sin(a)), p);
                }
                break;

            case DROP:
                path.moveTo(0, -10.5f);
                path.cubicTo(3, -6, 7, -2, 7, 3);
                path.arcTo(new RectF(-7, -4, 7, 10), 0, 180);
                path.cubicTo(-7, -2, -3, -6, 0, -10.5f);
                path.close();
                c.drawPath(path, p);
                c.drawArc(new RectF(-4, -1, 4, 7), 90, 70, false, p);
                break;

            case FAN:
                for (int k = 0; k < 3; k++) {
                    c.save();
                    c.rotate(k * 120 + 15);
                    path.reset();
                    path.moveTo(0, -1.5f);
                    path.cubicTo(-5, -3, -4, -10.5f, 0.5f, -10.5f);
                    path.cubicTo(4.5f, -10.5f, 4, -4, 0, -1.5f);
                    c.drawPath(path, p);
                    c.restore();
                }
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(0, 0, 2f, p);
                break;

            case AUTO:
                c.drawLine(-6.5f, 9, 0, -9, p);
                c.drawLine(0, -9, 6.5f, 9, p);
                c.drawLine(-3.8f, 2.5f, 3.8f, 2.5f, p);
                break;

            case BOLT:
                p.setStyle(Paint.Style.FILL_AND_STROKE);
                p.setStrokeWidth(1.2f);
                path.moveTo(2.5f, -11);
                path.lineTo(-6.5f, 2);
                path.lineTo(-0.5f, 2);
                path.lineTo(-2.5f, 11);
                path.lineTo(6.5f, -2);
                path.lineTo(0.5f, -2);
                path.close();
                c.drawPath(path, p);
                break;

            case MOON: {
                p.setStyle(Paint.Style.FILL);
                Path a = new Path();
                a.addCircle(0, 0, 9, Path.Direction.CW);
                Path m = new Path();
                m.addCircle(5, -4, 8, Path.Direction.CW);
                a.op(m, Path.Op.DIFFERENCE);
                c.drawPath(a, p);
                c.drawCircle(7, 4, 1.2f, p);
                break;
            }

            case BULB:
                c.drawArc(new RectF(-6.5f, -11.5f, 6.5f, 1.5f), 140, 260, false, p);
                c.drawLine(-5, -0.8f, -3, 4.5f, p);
                c.drawLine(5, -0.8f, 3, 4.5f, p);
                c.drawLine(-3, 4.5f, 3, 4.5f, p);
                c.drawLine(-2.5f, 7.5f, 2.5f, 7.5f, p);
                c.drawLine(-1.2f, 10.5f, 1.2f, 10.5f, p);
                break;

            case WIND:
                path.moveTo(-10, -4);
                path.lineTo(5, -4);
                path.quadTo(9, -4, 9, -7.5f);
                path.quadTo(9, -11, 5.5f, -10.5f);
                path.moveTo(-10, 1);
                path.lineTo(9, 1);
                path.moveTo(-10, 6);
                path.lineTo(3, 6);
                path.quadTo(7, 6, 7, 9);
                path.quadTo(7, 12, 3.5f, 11.2f);
                c.drawPath(path, p);
                break;

            case LEAF:
                path.moveTo(-9, 9);
                path.cubicTo(-9, -5, 1, -10, 10, -10);
                path.cubicTo(10, -1, 5, 9, -9, 9);
                path.close();
                c.drawPath(path, p);
                c.drawLine(-9, 9, 3, -3, p);
                break;

            case THERMO:
                path.moveTo(-2.5f, 3.4f);
                path.lineTo(-2.5f, -7.5f);
                path.arcTo(new RectF(-2.5f, -10, 2.5f, -5), 180, 180);
                path.lineTo(2.5f, 3.4f);
                path.arcTo(new RectF(-4.8f, 2.8f, 4.8f, 12.4f), -58, 296);
                path.close();
                c.drawPath(path, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(0, 7.6f, 2, p);
                p.setStyle(Paint.Style.STROKE);
                c.drawLine(0, 6, 0, -3, p);
                break;

            case CLOCK:
                c.drawCircle(0, 0, 9.5f, p);
                c.drawLine(0, 0, 0, -5.5f, p);
                c.drawLine(0, 0, 4, 2.5f, p);
                break;

            case SCREEN:
                c.drawRoundRect(new RectF(-10, -8, 10, 5), 2, 2, p);
                c.drawLine(0, 5, 0, 9.5f, p);
                c.drawLine(-4.5f, 9.5f, 4.5f, 9.5f, p);
                p.setStrokeWidth(1.6f);
                c.drawLine(-5, -1.5f, -1, -1.5f, p);
                c.drawLine(2, -1.5f, 5, -1.5f, p);
                break;

            case GEAR:
                c.drawCircle(0, 0, 3, p);
                c.drawCircle(0, 0, 7, p);
                p.setStrokeWidth(3f);
                for (int k = 0; k < 8; k++) {
                    double a = Math.toRadians(k * 45);
                    c.drawLine((float) (8 * Math.cos(a)), (float) (8 * Math.sin(a)),
                            (float) (10 * Math.cos(a)), (float) (10 * Math.sin(a)), p);
                }
                break;

            case SIGNAL:
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(-6, 6, 2, p);
                p.setStyle(Paint.Style.STROKE);
                c.drawArc(new RectF(-13, -1, 1, 13), -90, 90, false, p);
                c.drawArc(new RectF(-18.5f, -6.5f, 6.5f, 18.5f), -90, 90, false, p);
                break;

            case PLUS:
                p.setStrokeWidth(2.4f);
                c.drawLine(-7, 0, 7, 0, p);
                c.drawLine(0, -7, 0, 7, p);
                break;

            case MINUS:
                p.setStrokeWidth(2.4f);
                c.drawLine(-7, 0, 7, 0, p);
                break;

            case PAUSE:
                drawUnit(c);
                p.setStrokeWidth(2.6f);
                c.drawLine(-3, -1, -3, 8, p);
                c.drawLine(3, -1, 3, 8, p);
                break;

            case ARROW: {
                drawUnit(c);
                double a = Math.toRadians(a1);
                float ex = (float) (ox + 15 * Math.cos(a)), ey = (float) (oy + 15 * Math.sin(a));
                c.drawLine(ox, oy, ex, ey, p);
                head(c, ex, ey, a1);
                break;
            }

            case ARC: {
                drawUnit(c);
                float r = 14;
                p.setAlpha(110);
                for (float ang : new float[]{a1, a2}) {
                    double a = Math.toRadians(ang);
                    c.drawLine(ox, oy, (float) (ox + (r - 4) * Math.cos(a)), (float) (oy + (r - 4) * Math.sin(a)), p);
                }
                p.setColor(color);
                c.drawArc(new RectF(ox - r, oy - r, ox + r, oy + r), a1, a2 - a1, false, p);
                double s1 = Math.toRadians(a1), s2 = Math.toRadians(a2);
                head(c, (float) (ox + r * Math.cos(s1)), (float) (oy + r * Math.sin(s1)), a1 - 90);
                head(c, (float) (ox + r * Math.cos(s2)), (float) (oy + r * Math.sin(s2)), a2 + 90);
                break;
            }

            case BARS:
                p.setStyle(Paint.Style.FILL);
                for (int k = 0; k < 3; k++) {
                    float x = -8 + k * 6.5f, h = 6 + k * 6;
                    p.setAlpha(k < level ? 255 : 70);
                    c.drawRoundRect(new RectF(x, 9 - h, x + 4, 9), 1.5f, 1.5f, p);
                }
                p.setAlpha(255);
                break;

            case INFO:
                c.drawCircle(0, 0, 9.5f, p);
                c.drawLine(0, -1, 0, 5.5f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(0, -5, 1.4f, p);
                break;
        }
        c.restore();
    }

    private void drawUnit(Canvas c) {
        if (!unitBar && type != PAUSE) return;
        float w = p.getStrokeWidth();
        p.setStrokeWidth(3f);
        c.drawLine(-10, -10, 10, -10, p);
        p.setStrokeWidth(w);
    }

    private void head(Canvas c, float x, float y, float dirDeg) {
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            double a = Math.toRadians(dirDeg + sgn * 150);
            c.drawLine(x, y, (float) (x + 4.5 * Math.cos(a)), (float) (y + 4.5 * Math.sin(a)), p);
        }
    }

    @Override
    public void setAlpha(int alpha) {
        p.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter cf) {
        p.setColorFilter(cf);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
