package ir.remote.gree;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Circular thermostat dial: 270° arc, draggable knob, big temperature readout. */
public class TempDial extends View {

    public interface Listener {
        void onTempChosen(int temp);
    }

    private static final float START = 135f, SWEEP = 270f;

    private int temp = 24, min = 16, max = 30;
    private int accent = 0xFF3DA5FF;
    private boolean power = true, showTemp = true;
    private String modeLabel = "", subLabel = "";
    private Listener listener;
    private boolean dragging;
    private float pulse; // 0..1

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    private final float d;

    public TempDial(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(0xFF1E2A36);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        glow.setStyle(Paint.Style.STROKE);
        glow.setStrokeCap(Paint.Cap.ROUND);
        tick.setStrokeCap(Paint.Cap.ROUND);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setColor(Color.WHITE);
    }

    public void setListener(Listener l) { listener = l; }

    public void setState(int temp, boolean power, boolean showTemp, int accent, String mode, String sub) {
        if (!dragging) this.temp = temp;
        this.power = power;
        this.showTemp = showTemp;
        this.accent = accent;
        this.modeLabel = mode;
        this.subLabel = sub;
        invalidate();
    }

    /** Short ring animation when an IR command is sent. */
    public void pulse() {
        ValueAnimator va = ValueAnimator.ofFloat(1f, 0f);
        va.setDuration(550);
        va.addUpdateListener(a -> {
            pulse = (float) a.getAnimatedValue();
            invalidate();
        });
        va.start();
    }

    @Override
    protected void onMeasure(int w, int h) {
        int width = MeasureSpec.getSize(w);
        int size = Math.min(width, (int) (300 * d));
        setMeasuredDimension(width, size);
    }

    private static int withAlpha(int c, int a) {
        return (c & 0x00FFFFFF) | (a << 24);
    }

    @Override
    protected void onDraw(Canvas c) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f + 6 * d;
        float stroke = 14 * d;
        float r = Math.min(getWidth(), getHeight()) / 2f - stroke * 1.4f;
        oval.set(cx - r, cy - r, cx + r, cy + r);

        int col = power ? accent : 0xFF55626F;
        float frac = (temp - min) / (float) (max - min);

        // inner disc
        inner.setStyle(Paint.Style.FILL);
        inner.setColor(withAlpha(col, power ? 26 : 12));
        c.drawCircle(cx, cy, r - stroke * 1.3f, inner);
        inner.setStyle(Paint.Style.STROKE);
        inner.setStrokeWidth(1 * d);
        inner.setColor(withAlpha(col, 60));
        c.drawCircle(cx, cy, r - stroke * 1.3f, inner);

        // send pulse ring
        if (pulse > 0) {
            inner.setStrokeWidth(3 * d);
            inner.setColor(withAlpha(col, (int) (pulse * 160)));
            c.drawCircle(cx, cy, r + stroke * (1.6f - pulse), inner);
        }

        // ticks
        for (int i = 0; i <= max - min; i++) {
            double a = Math.toRadians(START + SWEEP * i / (max - min));
            float r1 = r - stroke * 1.05f, r2 = r1 - (i % 2 == 0 ? 7 : 4) * d;
            tick.setStrokeWidth(1.6f * d);
            tick.setColor(i <= frac * (max - min) && power && showTemp ? withAlpha(col, 200) : 0x33FFFFFF);
            c.drawLine(cx + (float) (r1 * Math.cos(a)), cy + (float) (r1 * Math.sin(a)),
                    cx + (float) (r2 * Math.cos(a)), cy + (float) (r2 * Math.sin(a)), tick);
        }

        // track
        track.setStrokeWidth(stroke);
        c.drawArc(oval, START, SWEEP, false, track);

        if (showTemp) {
            // gradient progress
            // gradient seam is placed 10° before the arc start so the round cap stays clean
            int[] colors = {withAlpha(col, 90), withAlpha(col, 90), col, 0xFFFFFFFF, 0xFFFFFFFF};
            float[] pos = {0f, 0.028f, 0.75f, 0.785f, 1f};
            SweepGradient g = new SweepGradient(cx, cy, colors, pos);
            Matrix m = new Matrix();
            m.setRotate(START - 10, cx, cy);
            g.setLocalMatrix(m);
            arc.setShader(g);
            arc.setStrokeWidth(stroke);
            float sw = Math.max(0.5f, SWEEP * frac);
            glow.setStrokeWidth(stroke * 2.2f);
            glow.setColor(withAlpha(col, power ? 40 : 10));
            c.drawArc(oval, START, sw, false, glow);
            c.drawArc(oval, START, sw, false, arc);

            // knob
            double a = Math.toRadians(START + sw);
            float kx = cx + (float) (r * Math.cos(a)), ky = cy + (float) (r * Math.sin(a));
            knob.setStyle(Paint.Style.FILL);
            knob.setColor(withAlpha(col, 70));
            c.drawCircle(kx, ky, stroke * (dragging ? 1.25f : 0.95f), knob);
            knob.setColor(Color.WHITE);
            c.drawCircle(kx, ky, stroke * 0.55f, knob);
        }

        // texts
        txt.setTypeface(Typeface.DEFAULT_BOLD);
        txt.setTextSize(15 * d);
        txt.setColor(power ? col : 0xFFE5484D);
        c.drawText(power ? modeLabel : "خاموش", cx, cy - r * 0.42f, txt);

        txt.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        txt.setTextSize(r * 0.62f);
        txt.setColor(power ? Color.WHITE : 0xFF6B7885);
        String big = showTemp ? MainActivity.fa(temp) : "--";
        float tw = txt.measureText(big);
        c.drawText(big, cx, cy + r * 0.2f, txt);
        if (showTemp) {
            txt.setTextSize(r * 0.16f);
            txt.setTextAlign(Paint.Align.LEFT);
            c.drawText("°C", cx + tw / 2f + 2 * d, cy - r * 0.18f, txt);
            txt.setTextAlign(Paint.Align.CENTER);
        }

        txt.setTypeface(Typeface.DEFAULT);
        txt.setTextSize(12.5f * d);
        txt.setColor(0xFF8A99A8);
        c.drawText(subLabel, cx, cy + r * 0.45f, txt);

        // min / max labels at arc ends
        txt.setTextSize(11 * d);
        txt.setColor(0x88FFFFFF);
        double s = Math.toRadians(START), e = Math.toRadians(START + SWEEP);
        float lr = r + stroke * 0.2f;
        c.drawText(MainActivity.fa(min) + "°", cx + (float) (lr * Math.cos(s)), cy + (float) (lr * Math.sin(s)) + stroke * 1.6f, txt);
        c.drawText(MainActivity.fa(max) + "°", cx + (float) (lr * Math.cos(e)), cy + (float) (lr * Math.sin(e)) + stroke * 1.6f, txt);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!showTemp) return false;
        float cx = getWidth() / 2f, cy = getHeight() / 2f + 6 * d;
        float dx = ev.getX() - cx, dy = ev.getY() - cy;
        float dist = (float) Math.hypot(dx, dy);
        float r = Math.min(getWidth(), getHeight()) / 2f - 14 * d * 1.4f;

        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (dist < r * 0.6f || dist > r * 1.35f) return false;
                dragging = true;
                getParent().requestDisallowInterceptTouchEvent(true);
                // fall through
            case MotionEvent.ACTION_MOVE: {
                float ang = (float) Math.toDegrees(Math.atan2(dy, dx));
                float rel = ang - START;
                while (rel < 0) rel += 360;
                if (rel > SWEEP) rel = (rel > SWEEP + (360 - SWEEP) / 2) ? 0 : SWEEP;
                int t = min + Math.round(rel / SWEEP * (max - min));
                if (t != temp) {
                    temp = t;
                    performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK);
                }
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging) {
                    dragging = false;
                    invalidate();
                    if (listener != null) listener.onTempChosen(temp);
                }
                return true;
        }
        return super.onTouchEvent(ev);
    }
}
