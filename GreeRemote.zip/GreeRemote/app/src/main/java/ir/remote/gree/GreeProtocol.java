package ir.remote.gree;

/**
 * Gree AC IR protocol encoder (R410A split units, remotes YAW1F / YB1FA / YBOF).
 * 8-byte state, 38 kHz, sent as two 4-byte blocks with a 3-bit "010" footer.
 * Bit layout follows the widely-tested IRremoteESP8266 implementation.
 */
public class GreeProtocol {

    public static final int FREQ = 38000;

    // Timings (microseconds)
    private static final int HDR_MARK = 9000;
    private static final int HDR_SPACE = 4500;
    private static final int BIT_MARK = 620;
    private static final int ONE_SPACE = 1600;
    private static final int ZERO_SPACE = 540;
    private static final int MSG_SPACE = 19980;

    // Modes
    public static final int MODE_AUTO = 0, MODE_COOL = 1, MODE_DRY = 2, MODE_FAN = 3, MODE_HEAT = 4;
    // Fan
    public static final int FAN_AUTO = 0, FAN_LOW = 1, FAN_MED = 2, FAN_HIGH = 3;
    // Vertical swing
    public static final int SWV_LAST = 0, SWV_AUTO = 1, SWV_UP = 2, SWV_MID_UP = 3, SWV_MID = 4,
            SWV_MID_DOWN = 5, SWV_DOWN = 6, SWV_DOWN_AUTO = 7, SWV_MID_AUTO = 9, SWV_UP_AUTO = 11;
    // Horizontal swing
    public static final int SWH_OFF = 0, SWH_AUTO = 1, SWH_MAX_LEFT = 2, SWH_LEFT = 3, SWH_MID = 4,
            SWH_RIGHT = 5, SWH_MAX_RIGHT = 6;
    // Display temperature source
    public static final int DISP_OFF = 0, DISP_SET = 1, DISP_INSIDE = 2, DISP_OUTSIDE = 3;

    public static final int MIN_TEMP = 16, MAX_TEMP = 30;

    // ---- state ----
    public boolean power = false;
    public int mode = MODE_COOL;
    public int temp = 24;
    public int fan = FAN_AUTO;
    public int swingV = SWV_AUTO;
    public int swingH = SWH_OFF;
    public boolean turbo = false;
    public boolean sleep = false;
    public boolean light = true;
    public boolean xfan = false;
    public boolean econo = false;
    public boolean iFeel = false;
    public int display = DISP_SET;
    public int timerMinutes = 0;     // 0 = off, max 24h, 30-min steps
    public boolean modelYaw1f = true; // YAW1F (most common) vs YBOF

    public static boolean isAutoSwing(int v) {
        return v == SWV_AUTO || v == SWV_DOWN_AUTO || v == SWV_MID_AUTO || v == SWV_UP_AUTO;
    }

    /** Build the 8-byte state. */
    public byte[] toBytes() {
        int[] b = new int[8];
        int f = (mode == MODE_DRY) ? FAN_LOW : fan;
        int t = Math.max(MIN_TEMP, Math.min(MAX_TEMP, temp)) - MIN_TEMP;
        int mins = Math.max(0, Math.min(24 * 60, timerMinutes)) / 30 * 30;
        int hours = mins / 60;

        // Byte 0: Mode(3) Power(1) Fan(2) SwingAuto(1) Sleep(1)
        b[0] = (mode & 0x7) | (power ? 0x08 : 0) | ((f & 0x3) << 4)
                | (isAutoSwing(swingV) ? 0x40 : 0) | (sleep ? 0x80 : 0);
        // Byte 1: Temp(4) TimerHalfHr(1) TimerTensHr(2) TimerEnabled(1)
        b[1] = (t & 0xF) | (((mins % 60) >= 30) ? 0x10 : 0) | (((hours / 10) & 0x3) << 5)
                | ((mins >= 30) ? 0x80 : 0);
        // Byte 2: TimerHours(4) Turbo(1) Light(1) ModelA/Power2(1) Xfan(1)
        boolean xfanOk = xfan && (mode == MODE_COOL || mode == MODE_DRY);
        b[2] = ((hours % 10) & 0xF) | (turbo ? 0x10 : 0) | (light ? 0x20 : 0)
                | ((power && modelYaw1f) ? 0x40 : 0) | (xfanOk ? 0x80 : 0);
        // Byte 3: unknown fixed 0b0101 in high nibble
        b[3] = 0x50;
        // Byte 4: SwingV(4) SwingH(3)
        b[4] = (swingV & 0xF) | ((swingH & 0x7) << 4);
        // Byte 5: DisplayTemp(2) IFeel(1) unknown 0b100(3) WiFi(1)
        b[5] = (display & 0x3) | (iFeel ? 0x04 : 0) | 0x20;
        b[6] = 0x00;
        // Byte 7: Econo bit2, checksum in high nibble
        b[7] = econo ? 0x04 : 0;

        int sum = 10;
        for (int i = 0; i < 4; i++) sum += b[i] & 0xF;
        for (int i = 4; i < 7; i++) sum += (b[i] >> 4) & 0xF;
        b[7] |= (sum & 0xF) << 4;

        byte[] out = new byte[8];
        for (int i = 0; i < 8; i++) out[i] = (byte) b[i];
        return out;
    }

    /** Build an Android ConsumerIrManager pattern (alternating mark/space, µs). */
    public int[] toPattern() {
        byte[] d = toBytes();
        int[] p = new int[2 + 32 * 2 + 3 * 2 + 2 + 32 * 2 + 1];
        int i = 0;
        p[i++] = HDR_MARK;
        p[i++] = HDR_SPACE;
        for (int k = 0; k < 4; k++) i = putByte(p, i, d[k] & 0xFF, 8);
        i = putByte(p, i, 0b010, 3);           // block footer
        p[i++] = BIT_MARK;
        p[i++] = MSG_SPACE;
        for (int k = 4; k < 8; k++) i = putByte(p, i, d[k] & 0xFF, 8);
        p[i++] = BIT_MARK;                     // trailing mark
        return p;
    }

    private static int putByte(int[] p, int i, int v, int bits) {
        for (int b = 0; b < bits; b++) {      // LSB first
            p[i++] = BIT_MARK;
            p[i++] = ((v >> b) & 1) == 1 ? ONE_SPACE : ZERO_SPACE;
        }
        return i;
    }

    public static String hex(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (byte x : d) sb.append(String.format("%02X ", x & 0xFF));
        return sb.toString().trim();
    }
}
