package ir.remote.gree;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Rounded touch tile with an icon and an optional label / value line. */
public class Tile extends LinearLayout {

    static final int SURFACE = 0xFF18222C;
    static final int STROKE = 0xFF263340;
    static final int TEXT = 0xFFE8EEF3;
    static final int MUTED = 0xFF8A99A8;

    private final Icon icon;
    private final ImageView iv;
    private final TextView label;
    private final TextView value;
    private final float d;
    private final float radius;
    private boolean active;
    private int accent = 0xFF3DA5FF;

    /**
     * @param horizontal icon beside text (wide tiles) instead of above it
     */
    public Tile(Context c, Icon icon, String text, boolean horizontal, float iconDp, float radiusDp) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        this.icon = icon;
        this.radius = radiusDp * d;
        setOrientation(horizontal ? HORIZONTAL : VERTICAL);
        setGravity(Gravity.CENTER);
        int pad = (int) (6 * d);
        setPadding(horizontal ? (int) (14 * d) : pad, pad, horizontal ? (int) (14 * d) : pad, pad);
        setClickable(true);
        setFocusable(true);

        iv = new ImageView(c);
        iv.setImageDrawable(icon);
        int is = (int) (iconDp * d);
        addView(iv, new LayoutParams(is, is));

        LinearLayout texts = new LinearLayout(c);
        texts.setOrientation(VERTICAL);
        texts.setGravity(horizontal ? Gravity.START | Gravity.CENTER_VERTICAL : Gravity.CENTER);
        label = new TextView(c);
        label.setTextSize(12);
        label.setTextColor(MUTED);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setText(text);
        value = new TextView(c);
        value.setTextSize(14);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        value.setTextColor(TEXT);
        value.setVisibility(GONE);
        texts.addView(label);
        texts.addView(value);
        LayoutParams lp = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        if (horizontal) lp.setMarginStart((int) (12 * d));
        else lp.topMargin = (int) (4 * d);
        if (text == null || text.isEmpty()) texts.setVisibility(GONE);
        addView(texts, lp);
        if (horizontal) label.setGravity(Gravity.START);

        setActive(false, accent);
    }

    public void setValue(String v) {
        value.setVisibility(VISIBLE);
        value.setText(v);
    }

    public void setLabel(String s) {
        label.setText(s);
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean on, int color) {
        active = on;
        accent = color;
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(radius);
        if (on) {
            bg.setOrientation(GradientDrawable.Orientation.TL_BR);
            bg.setColors(new int[]{mix(color, 0xFF000000, 0.15f), mix(color, 0xFF000000, 0.45f)});
            bg.setStroke((int) (1 * d), mix(color, 0xFFFFFFFF, 0.3f));
        } else {
            bg.setColor(SURFACE);
            bg.setStroke((int) (1 * d), STROKE);
        }
        GradientDrawable mask = new GradientDrawable();
        mask.setCornerRadius(radius);
        mask.setColor(0xFFFFFFFF);
        setBackground(new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, mask));
        icon.setColor(on ? 0xFFFFFFFF : color);
        label.setTextColor(on ? 0xE6FFFFFF : MUTED);
        value.setTextColor(on ? 0xFFFFFFFF : TEXT);
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        setAlpha(enabled ? 1f : 0.35f);
    }

    static int mix(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return 0xFF000000
                | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8)
                | (int) (ab + (bb - ab) * t);
    }
}
