package ir.remote.gree;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    // Palette
    private static final int BG_TOP = 0xFF0A0F14, BG_BOTTOM = 0xFF101A23;
    private static final int CARD = 0xFF111A22;
    private static final int TEXT = 0xFFE8EEF3, MUTED = 0xFF8A99A8;
    private static final int GREEN = 0xFF1FC27A, RED = 0xFFFF5A5F, BLUE = 0xFF3DA5FF;
    private static final int[] MODE_COLORS = {0xFFA084FF, 0xFF3DA5FF, 0xFF2BD4C0, 0xFF7ED957, 0xFFFF8A3D};

    private static final String[] MODE_NAMES = {"خودکار", "سرمایش", "خشک‌کن", "فن", "گرمایش"};
    private static final int[] MODE_ICONS = {Icon.AUTO, Icon.SNOW, Icon.DROP, Icon.FAN, Icon.SUN};
    private static final String[] FAN_NAMES = {"خودکار", "کم", "متوسط", "زیاد"};
    private static final String[] DISP_NAMES = {"خاموش", "دمای تنظیمی", "دمای داخل", "دمای بیرون"};

    // Vertical air direction: buttons in visual order (left → right)
    private static final int[] V_MAIN = {GreeProtocol.SWV_LAST, GreeProtocol.SWV_AUTO, GreeProtocol.SWV_UP,
            GreeProtocol.SWV_MID_UP, GreeProtocol.SWV_MID, GreeProtocol.SWV_MID_DOWN, GreeProtocol.SWV_DOWN};
    private static final int[] V_ZONE = {GreeProtocol.SWV_UP_AUTO, GreeProtocol.SWV_MID_AUTO, GreeProtocol.SWV_DOWN_AUTO};
    private static final int[] H_MAIN = {GreeProtocol.SWH_OFF, GreeProtocol.SWH_AUTO, GreeProtocol.SWH_MAX_LEFT,
            GreeProtocol.SWH_LEFT, GreeProtocol.SWH_MID, GreeProtocol.SWH_RIGHT, GreeProtocol.SWH_MAX_RIGHT};

    private final GreeProtocol ac = new GreeProtocol();
    private ConsumerIrManager ir;
    private SharedPreferences prefs;
    private boolean haptics = true;

    private TempDial dial;
    private TextView irStatus, vCaption, hCaption;
    private Tile power, plus, minus, resend;
    private final Tile[] modeTiles = new Tile[5];
    private final Tile[] fanTiles = new Tile[4];
    private final Tile[] vTiles = new Tile[7];
    private final Tile[] vZoneTiles = new Tile[3];
    private final Tile[] hTiles = new Tile[7];
    private Tile tTurbo, tSleep, tLight, tXfan, tEcono, tIfeel, tTimer, tDisplay;
    private LinearLayout content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupEdgeToEdge();

        prefs = getSharedPreferences("gree", MODE_PRIVATE);
        loadState();
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);

        setContentView(buildUi());
        refresh();
    }

    // ================================================================ window

    @SuppressWarnings("deprecation")
    private void setupEdgeToEdge() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        if (Build.VERSION.SDK_INT < 35) {
            w.setStatusBarColor(0x00000000);
            w.setNavigationBarColor(0x00000000);
        }
    }

    @SuppressWarnings("deprecation")
    private void applyInsets(View v, WindowInsets in) {
        int top, bottom;
        if (Build.VERSION.SDK_INT >= 30) {
            Insets i = in.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            top = i.top;
            bottom = i.bottom;
        } else {
            top = in.getSystemWindowInsetTop();
            bottom = in.getSystemWindowInsetBottom();
        }
        content.setPadding(dp(16), top + dp(14), dp(16), bottom + dp(24));
    }

    // ================================================================ UI

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        scroll.setVerticalScrollBarEnabled(false);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_TOP, BG_BOTTOM});
        scroll.setBackground(bg);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(dp(16), dp(36), dp(16), dp(24));
        scroll.addView(content);
        scroll.setOnApplyWindowInsetsListener((v, in) -> {
            applyInsets(v, in);
            return in;
        });

        // ---------- header
        LinearLayout header = hRow();
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(getString(R.string.app_name), 22, TEXT, true);
        irStatus = text("", 12, MUTED, false);
        irStatus.setCompoundDrawablePadding(dp(6));
        titles.addView(title);
        titles.addView(irStatus);
        header.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Tile gear = new Tile(this, new Icon(Icon.GEAR, MUTED), null, false, 22, 22);
        gear.setOnClickListener(v -> showSettings());
        header.addView(gear, new LinearLayout.LayoutParams(dp(44), dp(44)));
        content.addView(header);

        // ---------- dial card
        LinearLayout dialCard = card();
        dial = new TempDial(this);
        dial.setListener(t -> {
            if (t != ac.temp) {
                ac.temp = t;
                apply();
            }
        });
        dialCard.addView(dial, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout ctrl = hRow();
        ctrl.setGravity(Gravity.CENTER);
        ctrl.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        minus = new Tile(this, new Icon(Icon.MINUS, TEXT), null, false, 26, 30);
        minus.setOnClickListener(v -> changeTemp(-1));
        power = new Tile(this, new Icon(Icon.POWER, RED), null, false, 34, 40);
        power.setOnClickListener(v -> {
            ac.power = !ac.power;
            apply();
        });
        plus = new Tile(this, new Icon(Icon.PLUS, TEXT), null, false, 26, 30);
        plus.setOnClickListener(v -> changeTemp(+1));
        LinearLayout.LayoutParams small = new LinearLayout.LayoutParams(dp(60), dp(60));
        LinearLayout.LayoutParams big = new LinearLayout.LayoutParams(dp(80), dp(80));
        big.setMargins(dp(26), 0, dp(26), 0);
        ctrl.addView(minus, small);
        ctrl.addView(power, big);
        ctrl.addView(plus, new LinearLayout.LayoutParams(dp(60), dp(60)));
        LinearLayout.LayoutParams clp = matchWrap();
        clp.topMargin = dp(4);
        dialCard.addView(ctrl, clp);
        content.addView(dialCard, cardLp(14));

        // ---------- mode
        LinearLayout modeCard = card();
        modeCard.addView(sectionTitle("حالت کار", null));
        LinearLayout mr = hRow();
        for (int i = 0; i < 5; i++) {
            final int m = i;
            modeTiles[i] = new Tile(this, new Icon(MODE_ICONS[i], MODE_COLORS[i]), MODE_NAMES[i], false, 26, 18);
            modeTiles[i].setOnClickListener(v -> {
                ac.mode = m;
                if (m != GreeProtocol.MODE_COOL && m != GreeProtocol.MODE_DRY) ac.xfan = false;
                apply();
            });
            mr.addView(modeTiles[i], cell(78, 3));
        }
        modeCard.addView(mr);

        modeCard.addView(sectionTitle("سرعت فن", null));
        LinearLayout fr = hRow();
        for (int i = 0; i < 4; i++) {
            final int f = i;
            Icon ic = i == 0 ? new Icon(Icon.AUTO, BLUE) : Icon.bars(BLUE, i);
            fanTiles[i] = new Tile(this, ic, FAN_NAMES[i], false, 22, 16);
            fanTiles[i].setOnClickListener(v -> {
                ac.fan = f;
                apply();
            });
            fr.addView(fanTiles[i], cell(68, 3));
        }
        modeCard.addView(fr);
        content.addView(modeCard, cardLp(14));

        // ---------- air direction
        LinearLayout dirCard = card();
        vCaption = text("", 12, BLUE, true);
        dirCard.addView(sectionTitle("جهت باد عمودی", vCaption));
        LinearLayout vr = hRow();
        vr.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Icon[] vIcons = {
                new Icon(Icon.PAUSE, BLUE),
                Icon.arc(BLUE, 15, 85, true),
                Icon.arrow(BLUE, 12, true),
                Icon.arrow(BLUE, 30, true),
                Icon.arrow(BLUE, 48, true),
                Icon.arrow(BLUE, 66, true),
                Icon.arrow(BLUE, 84, true)};
        for (int i = 0; i < 7; i++) {
            final int v = V_MAIN[i];
            vTiles[i] = new Tile(this, vIcons[i], null, false, 28, 14);
            vTiles[i].setOnClickListener(x -> {
                ac.swingV = v;
                apply();
            });
            vr.addView(vTiles[i], cell(54, 2.5f));
        }
        dirCard.addView(vr);

        LinearLayout zr = hRow();
        zr.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Icon[] zIcons = {Icon.arc(BLUE, 8, 42, true), Icon.arc(BLUE, 32, 66, true), Icon.arc(BLUE, 55, 88, true)};
        String[] zNames = {"نوسان بالا", "نوسان وسط", "نوسان پایین"};
        for (int i = 0; i < 3; i++) {
            final int v = V_ZONE[i];
            vZoneTiles[i] = new Tile(this, zIcons[i], zNames[i], true, 22, 14);
            vZoneTiles[i].setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            vZoneTiles[i].setPadding(dp(6), dp(4), dp(6), dp(4));
            vZoneTiles[i].setOnClickListener(x -> {
                ac.swingV = v;
                apply();
            });
            LinearLayout.LayoutParams lp = cell(46, 2.5f);
            lp.topMargin = dp(6);
            zr.addView(vZoneTiles[i], lp);
        }
        dirCard.addView(zr);

        hCaption = text("", 12, BLUE, true);
        dirCard.addView(sectionTitle("جهت باد افقی", hCaption));
        LinearLayout hr = hRow();
        hr.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Icon[] hIcons = {
                new Icon(Icon.PAUSE, BLUE),
                Icon.arc(BLUE, 45, 135, false),
                Icon.arrow(BLUE, 135, false),
                Icon.arrow(BLUE, 112, false),
                Icon.arrow(BLUE, 90, false),
                Icon.arrow(BLUE, 68, false),
                Icon.arrow(BLUE, 45, false)};
        for (int i = 0; i < 7; i++) {
            final int h = H_MAIN[i];
            hTiles[i] = new Tile(this, hIcons[i], null, false, 28, 14);
            hTiles[i].setOnClickListener(x -> {
                ac.swingH = h;
                apply();
            });
            hr.addView(hTiles[i], cell(54, 2.5f));
        }
        dirCard.addView(hr);
        content.addView(dirCard, cardLp(14));

        // ---------- features
        LinearLayout featCard = card();
        featCard.addView(sectionTitle("امکانات", null));
        tTurbo = feature(Icon.BOLT, 0xFFFFC233, "توربو", v -> { ac.turbo = !ac.turbo; apply(); });
        tSleep = feature(Icon.MOON, 0xFFA084FF, "خواب", v -> { ac.sleep = !ac.sleep; apply(); });
        tLight = feature(Icon.BULB, 0xFFFFD866, "چراغ پنل", v -> { ac.light = !ac.light; apply(); });
        tXfan = feature(Icon.WIND, 0xFF2BD4C0, "X-Fan", v -> {
            if (ac.mode != GreeProtocol.MODE_COOL && ac.mode != GreeProtocol.MODE_DRY) {
                toast("X-Fan فقط در حالت سرمایش و خشک‌کن فعال می‌شود");
                return;
            }
            ac.xfan = !ac.xfan;
            apply();
        });
        tEcono = feature(Icon.LEAF, GREEN, "صرفه‌جویی", v -> { ac.econo = !ac.econo; apply(); });
        tIfeel = feature(Icon.THERMO, 0xFFFF7A90, "I-Feel", v -> { ac.iFeel = !ac.iFeel; apply(); });
        featCard.addView(row3(tTurbo, tSleep, tLight));
        featCard.addView(row3(tXfan, tEcono, tIfeel));

        tTimer = new Tile(this, new Icon(Icon.CLOCK, 0xFFFFA94D), "تایمر", true, 26, 18);
        tTimer.setOnClickListener(v -> pickTimer());
        tDisplay = new Tile(this, new Icon(Icon.SCREEN, BLUE), "نمایشگر پنل", true, 26, 18);
        tDisplay.setOnClickListener(v -> pickDisplay());
        LinearLayout tr = hRow();
        tr.addView(tTimer, cell(64, 3));
        tr.addView(tDisplay, cell(64, 3));
        LinearLayout.LayoutParams tlp = matchWrap();
        tlp.topMargin = dp(6);
        featCard.addView(tr, tlp);
        content.addView(featCard, cardLp(14));

        // ---------- resend
        resend = new Tile(this, new Icon(Icon.SIGNAL, BLUE), "ارسال دوباره وضعیت فعلی", true, 22, 18);
        resend.setOnClickListener(v -> send());
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        rlp.topMargin = dp(14);
        content.addView(resend, rlp);

        TextView foot = text("این برنامه محصول رسمی Gree نیست و فقط با پروتکل مادون قرمز آن سازگار است.", 11, 0xFF5E6B78, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(dp(8), dp(16), dp(8), 0);
        content.addView(foot);

        return scroll;
    }

    // ================================================================ actions

    private void changeTemp(int d) {
        if (ac.mode == GreeProtocol.MODE_FAN) {
            toast("در حالت فن دما قابل تنظیم نیست");
            return;
        }
        int t = ac.temp + d;
        if (t < GreeProtocol.MIN_TEMP || t > GreeProtocol.MAX_TEMP) {
            toast("محدوده دما " + fa(GreeProtocol.MIN_TEMP) + " تا " + fa(GreeProtocol.MAX_TEMP) + " درجه است");
            return;
        }
        ac.temp = t;
        apply();
    }

    private void pickTimer() {
        final String[] items = new String[49];
        items[0] = "خاموش";
        for (int i = 1; i <= 48; i++) items[i] = timerLabel(i * 30);
        dialog().setTitle(ac.power ? "خاموش شدن خودکار بعد از…" : "روشن شدن خودکار بعد از…")
                .setSingleChoiceItems(items, ac.timerMinutes / 30, (dlg, w) -> {
                    ac.timerMinutes = w * 30;
                    dlg.dismiss();
                    apply();
                }).show();
    }

    private void pickDisplay() {
        dialog().setTitle("دمای نمایش داده شده روی پنل کولر")
                .setSingleChoiceItems(DISP_NAMES, ac.display, (dlg, w) -> {
                    ac.display = w;
                    dlg.dismiss();
                    apply();
                }).show();
    }

    private void showSettings() {
        String[] items = {
                "مدل ریموت: " + (ac.modelYaw1f ? "YAW1F" : "YBOF"),
                "لرزش هنگام لمس: " + (haptics ? "روشن" : "خاموش"),
                "درباره برنامه و حریم خصوصی"};
        dialog().setTitle("تنظیمات").setItems(items, (dlg, w) -> {
            if (w == 0) pickModel();
            else if (w == 1) {
                haptics = !haptics;
                saveState();
                toast("لرزش " + (haptics ? "روشن" : "خاموش") + " شد");
            } else showAbout();
        }).show();
    }

    private void pickModel() {
        String[] models = {"YAW1F / YB1FA (رایج‌ترین)", "YBOF و سایر مدل‌ها"};
        dialog().setTitle("مدل ریموت اصلی کولر")
                .setSingleChoiceItems(models, ac.modelYaw1f ? 0 : 1, (dlg, w) -> {
                    ac.modelYaw1f = (w == 0);
                    dlg.dismiss();
                    saveState();
                    toast("اگر کولر واکنش نشان نداد، مدل دیگر را امتحان کنید");
                }).show();
    }

    private void showAbout() {
        String ver = "";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            ver = pi.versionName;
        } catch (Exception ignored) {
        }
        dialog().setTitle(getString(R.string.app_name) + " " + ver)
                .setMessage("ریموت کنترل کولر گازی با فرستنده مادون قرمز (IR) گوشی.\n\n"
                        + "حریم خصوصی: این برنامه به اینترنت دسترسی ندارد و هیچ اطلاعاتی جمع‌آوری یا ارسال نمی‌کند. "
                        + "تنظیمات فقط روی خود گوشی ذخیره می‌شود.\n\n"
                        + "Gree نام تجاری متعلق به صاحب آن است. این برنامه محصول رسمی Gree نیست.")
                .setPositiveButton("باشه", null).show();
    }

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert);
    }

    private void apply() {
        refresh();
        saveState();
        send();
    }

    private void send() {
        if (haptics) content.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        if (ir == null || !ir.hasIrEmitter()) {
            toast("فرستنده مادون قرمز (IR) روی این گوشی پیدا نشد");
            return;
        }
        try {
            ir.transmit(GreeProtocol.FREQ, ac.toPattern());
            dial.pulse();
        } catch (Exception e) {
            toast("خطا در ارسال: " + e.getMessage());
        }
    }

    // ================================================================ refresh

    private void refresh() {
        boolean on = ac.power;
        int mc = MODE_COLORS[ac.mode];
        boolean showTemp = ac.mode != GreeProtocol.MODE_FAN;
        int effFan = ac.mode == GreeProtocol.MODE_DRY ? GreeProtocol.FAN_LOW : ac.fan;

        String sub = "فن " + FAN_NAMES[effFan];
        if (ac.timerMinutes > 0) sub += "  •  تایمر " + timerLabel(ac.timerMinutes);
        dial.setState(ac.temp, on, showTemp, mc, MODE_NAMES[ac.mode], sub);

        power.setActive(on, on ? GREEN : RED);
        plus.setEnabled(showTemp);
        minus.setEnabled(showTemp);

        for (int i = 0; i < 5; i++) modeTiles[i].setActive(ac.mode == i, MODE_COLORS[i]);
        for (int i = 0; i < 4; i++) {
            fanTiles[i].setEnabled(ac.mode != GreeProtocol.MODE_DRY);
            fanTiles[i].setActive(effFan == i, BLUE);
        }

        String[] vNames = {"ثابت", "نوسان کامل", "بالا", "بالا-وسط", "وسط", "وسط-پایین", "پایین"};
        String[] zNames = {"نوسان بالا", "نوسان وسط", "نوسان پایین"};
        String vc = "";
        for (int i = 0; i < 7; i++) {
            vTiles[i].setActive(ac.swingV == V_MAIN[i], BLUE);
            if (ac.swingV == V_MAIN[i]) vc = vNames[i];
        }
        for (int i = 0; i < 3; i++) {
            vZoneTiles[i].setActive(ac.swingV == V_ZONE[i], BLUE);
            if (ac.swingV == V_ZONE[i]) vc = zNames[i];
        }
        vCaption.setText(vc);

        String[] hNames = {"خاموش", "نوسان کامل", "انتهای چپ", "چپ", "وسط", "راست", "انتهای راست"};
        for (int i = 0; i < 7; i++) {
            hTiles[i].setActive(ac.swingH == H_MAIN[i], BLUE);
            if (ac.swingH == H_MAIN[i]) hCaption.setText(hNames[i]);
        }

        tTurbo.setActive(ac.turbo, 0xFFFFB020);
        tSleep.setActive(ac.sleep, 0xFF8B6CFF);
        tLight.setActive(ac.light, 0xFFE0B020);
        boolean xOk = ac.mode == GreeProtocol.MODE_COOL || ac.mode == GreeProtocol.MODE_DRY;
        tXfan.setActive(ac.xfan, 0xFF20B5A3);
        tXfan.setAlpha(xOk ? 1f : 0.4f);
        tEcono.setActive(ac.econo, GREEN);
        tIfeel.setActive(ac.iFeel, 0xFFFF5C7A);

        tTimer.setActive(ac.timerMinutes > 0, 0xFFFF8F1F);
        tTimer.setValue(ac.timerMinutes == 0 ? "خاموش" : timerLabel(ac.timerMinutes));
        tDisplay.setActive(false, BLUE);
        tDisplay.setValue(DISP_NAMES[ac.display]);

        boolean hasIr = ir != null && ir.hasIrEmitter();
        irStatus.setText(hasIr ? "● فرستنده IR آماده است" : "● فرستنده IR پیدا نشد");
        irStatus.setTextColor(hasIr ? GREEN : RED);
    }

    // ================================================================ persistence

    private void loadState() {
        ac.power = prefs.getBoolean("power", false);
        ac.mode = prefs.getInt("mode", GreeProtocol.MODE_COOL);
        ac.temp = prefs.getInt("temp", 24);
        ac.fan = prefs.getInt("fan", GreeProtocol.FAN_AUTO);
        ac.swingV = prefs.getInt("swingV", GreeProtocol.SWV_AUTO);
        ac.swingH = prefs.getInt("swingH", GreeProtocol.SWH_OFF);
        ac.turbo = prefs.getBoolean("turbo", false);
        ac.sleep = prefs.getBoolean("sleep", false);
        ac.light = prefs.getBoolean("light", true);
        ac.xfan = prefs.getBoolean("xfan", false);
        ac.econo = prefs.getBoolean("econo", false);
        ac.iFeel = prefs.getBoolean("ifeel", false);
        ac.display = prefs.getInt("display", GreeProtocol.DISP_SET);
        ac.timerMinutes = prefs.getInt("timer", 0);
        ac.modelYaw1f = prefs.getBoolean("yaw1f", true);
        haptics = prefs.getBoolean("haptics", true);
    }

    private void saveState() {
        prefs.edit()
                .putBoolean("power", ac.power).putInt("mode", ac.mode).putInt("temp", ac.temp)
                .putInt("fan", ac.fan).putInt("swingV", ac.swingV).putInt("swingH", ac.swingH)
                .putBoolean("turbo", ac.turbo).putBoolean("sleep", ac.sleep).putBoolean("light", ac.light)
                .putBoolean("xfan", ac.xfan).putBoolean("econo", ac.econo).putBoolean("ifeel", ac.iFeel)
                .putInt("display", ac.display).putInt("timer", ac.timerMinutes)
                .putBoolean("yaw1f", ac.modelYaw1f).putBoolean("haptics", haptics)
                .apply();
    }

    // ================================================================ helpers

    static String fa(int n) {
        String s = String.valueOf(n);
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(c >= '0' && c <= '9' ? (char) ('۰' + (c - '0')) : c);
        return sb.toString();
    }

    private static String timerLabel(int mins) {
        int h = mins / 60;
        boolean half = mins % 60 >= 30;
        if (h == 0) return "۳۰ دقیقه";
        return fa(h) + (half ? "٫۵" : "") + " ساعت";
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout sectionTitle(String s, TextView caption) {
        LinearLayout r = hRow();
        r.setPadding(dp(4), dp(14), dp(4), dp(8));
        TextView t = text(s, 14, TEXT, true);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        if (caption != null) r.addView(caption);
        return r;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(4), dp(12), dp(14));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(26));
        g.setStroke(dp(1), 0xFF1A2530);
        c.setBackground(g);
        return c;
    }

    private LinearLayout.LayoutParams cardLp(int topDp) {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.topMargin = dp(topDp);
        return lp;
    }

    private LinearLayout hRow() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout.LayoutParams cell(int hDp, float marginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(hDp), 1);
        int m = dp(marginDp);
        lp.setMargins(m, 0, m, 0);
        return lp;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private Tile feature(int iconType, int color, String label, View.OnClickListener l) {
        Tile t = new Tile(this, new Icon(iconType, color), label, false, 26, 18);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row3(Tile a, Tile b, Tile c) {
        LinearLayout r = hRow();
        r.setPadding(0, 0, 0, dp(6));
        r.addView(a, cell(76, 3));
        r.addView(b, cell(76, 3));
        r.addView(c, cell(76, 3));
        return r;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
