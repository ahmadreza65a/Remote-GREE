package ir.remote.gree;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.ConsumerIrManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    // Colors
    private static final int BG = 0xFF0F1419;
    private static final int CARD = 0xFF1B232C;
    private static final int BTN = 0xFF26313C;
    private static final int TEXT = 0xFFE8EEF3;
    private static final int MUTED = 0xFF8A99A8;
    private static final int ACCENT = 0xFF2E9BFF;
    private static final int ON_GREEN = 0xFF1FB86A;
    private static final int OFF_RED = 0xFFE5484D;
    private static final int HEAT = 0xFFFF8A3D;

    private static final String[] MODE_NAMES = {"خودکار", "سرمایش", "خشک‌کن", "فن", "گرمایش"};
    private static final String[] MODE_ICONS = {"A", "❄", "💧", "✇", "☀"};
    private static final String[] FAN_NAMES = {"خودکار", "کم", "متوسط", "زیاد"};

    private static final int[] SWV_VALUES = {
            GreeProtocol.SWV_LAST, GreeProtocol.SWV_AUTO, GreeProtocol.SWV_UP, GreeProtocol.SWV_MID_UP,
            GreeProtocol.SWV_MID, GreeProtocol.SWV_MID_DOWN, GreeProtocol.SWV_DOWN,
            GreeProtocol.SWV_UP_AUTO, GreeProtocol.SWV_MID_AUTO, GreeProtocol.SWV_DOWN_AUTO};
    private static final String[] SWV_NAMES = {
            "ثابت (توقف)", "نوسان کامل", "بالا", "میانه‌-بالا", "وسط", "میانه‌-پایین", "پایین",
            "نوسان ناحیه بالا", "نوسان ناحیه وسط", "نوسان ناحیه پایین"};

    private static final int[] SWH_VALUES = {
            GreeProtocol.SWH_OFF, GreeProtocol.SWH_AUTO, GreeProtocol.SWH_MAX_LEFT, GreeProtocol.SWH_LEFT,
            GreeProtocol.SWH_MID, GreeProtocol.SWH_RIGHT, GreeProtocol.SWH_MAX_RIGHT};
    private static final String[] SWH_NAMES = {
            "خاموش", "نوسان کامل", "انتهای چپ", "چپ", "وسط", "راست", "انتهای راست"};

    private static final String[] DISP_NAMES = {"خاموش", "دمای تنظیمی", "دمای داخل", "دمای بیرون"};

    private final GreeProtocol ac = new GreeProtocol();
    private ConsumerIrManager ir;
    private SharedPreferences prefs;

    // Views
    private TextView tvTemp, tvMode, tvStatus, tvFlags, tvIr;
    private Button btnPower, btnSwingV, btnSwingH, btnTimer, btnDisplay;
    private final Button[] modeBtns = new Button[5];
    private final Button[] fanBtns = new Button[4];
    private Button tTurbo, tSleep, tLight, tXfan, tEcono, tIfeel;
    private LinearLayout displayCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        prefs = getSharedPreferences("gree", MODE_PRIVATE);
        loadState();

        if (Build.VERSION.SDK_INT >= 19) {
            ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        }

        setContentView(buildUi());
        refresh();
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(dp(16), dp(20), dp(16), dp(24));
        scroll.addView(root);

        // Header
        LinearLayout header = row();
        TextView title = text("ریموت اسپیلت گری", 20, TEXT, true);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        Button settings = smallButton("⚙", v -> showSettings());
        header.addView(settings, new LinearLayout.LayoutParams(dp(48), dp(44)));
        root.addView(header);

        tvIr = text("", 12, MUTED, false);
        tvIr.setPadding(0, dp(2), 0, dp(12));
        root.addView(tvIr);

        // Display card (LCD-like)
        displayCard = new LinearLayout(this);
        displayCard.setOrientation(LinearLayout.VERTICAL);
        displayCard.setGravity(Gravity.CENTER);
        displayCard.setPadding(dp(16), dp(18), dp(16), dp(18));
        displayCard.setBackground(round(CARD, 22));
        tvMode = text("", 16, MUTED, true);
        tvMode.setGravity(Gravity.CENTER);
        tvTemp = text("", 72, TEXT, true);
        tvTemp.setGravity(Gravity.CENTER);
        tvTemp.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        tvStatus = text("", 14, MUTED, false);
        tvStatus.setGravity(Gravity.CENTER);
        tvFlags = text("", 13, ACCENT, false);
        tvFlags.setGravity(Gravity.CENTER);
        tvFlags.setPadding(0, dp(6), 0, 0);
        displayCard.addView(tvMode);
        displayCard.addView(tvTemp);
        displayCard.addView(tvStatus);
        displayCard.addView(tvFlags);
        root.addView(displayCard, matchWrap());

        // Power + temp
        LinearLayout pr = row();
        pr.setPadding(0, dp(14), 0, 0);
        Button minus = bigButton("−", v -> changeTemp(-1));
        btnPower = bigButton("⏻", v -> {
            ac.power = !ac.power;
            apply();
        });
        btnPower.setTextSize(30);
        Button plus = bigButton("+", v -> changeTemp(+1));
        // RTL: plus appears on the right
        pr.addView(plus, weighted(1, dp(72)));
        pr.addView(spacer(10));
        pr.addView(btnPower, weighted(1.2f, dp(72)));
        pr.addView(spacer(10));
        pr.addView(minus, weighted(1, dp(72)));
        root.addView(pr);

        // Mode
        root.addView(section("حالت کار"));
        LinearLayout mr = row();
        for (int i = 0; i < 5; i++) {
            final int m = i;
            modeBtns[i] = chip(MODE_ICONS[i] + "\n" + MODE_NAMES[i], v -> {
                ac.mode = m;
                if (m != GreeProtocol.MODE_COOL && m != GreeProtocol.MODE_DRY) ac.xfan = false;
                apply();
            });
            modeBtns[i].setTextSize(13);
            if (i > 0) mr.addView(spacer(6));
            mr.addView(modeBtns[i], weighted(1, dp(64)));
        }
        root.addView(mr);

        // Fan
        root.addView(section("سرعت فن"));
        LinearLayout fr = row();
        for (int i = 0; i < 4; i++) {
            final int f = i;
            fanBtns[i] = chip(FAN_NAMES[i], v -> {
                ac.fan = f;
                apply();
            });
            if (i > 0) fr.addView(spacer(6));
            fr.addView(fanBtns[i], weighted(1, dp(48)));
        }
        root.addView(fr);

        // Swing
        root.addView(section("جهت باد (سوئینگ)"));
        LinearLayout sr = row();
        btnSwingV = chip("", v -> pickSwingV());
        btnSwingH = chip("", v -> pickSwingH());
        sr.addView(btnSwingV, weighted(1, dp(56)));
        sr.addView(spacer(8));
        sr.addView(btnSwingH, weighted(1, dp(56)));
        root.addView(sr);

        // Feature toggles
        root.addView(section("امکانات"));
        tTurbo = chip("🚀 توربو", v -> { ac.turbo = !ac.turbo; apply(); });
        tSleep = chip("🌙 خواب", v -> { ac.sleep = !ac.sleep; apply(); });
        tLight = chip("💡 چراغ نمایشگر", v -> { ac.light = !ac.light; apply(); });
        tXfan = chip("🌬 X-Fan (خشک‌کردن کویل)", v -> {
            if (ac.mode != GreeProtocol.MODE_COOL && ac.mode != GreeProtocol.MODE_DRY) {
                toast("X-Fan فقط در حالت سرمایش و خشک‌کن فعال است");
                return;
            }
            ac.xfan = !ac.xfan;
            apply();
        });
        tEcono = chip("🍃 صرفه‌جویی انرژی", v -> { ac.econo = !ac.econo; apply(); });
        tIfeel = chip("🌡 I-Feel", v -> { ac.iFeel = !ac.iFeel; apply(); });
        root.addView(pair(tTurbo, tSleep));
        root.addView(pair(tLight, tEcono));
        root.addView(pair(tXfan, tIfeel));

        // Timer + display
        root.addView(section("تایمر و نمایشگر"));
        btnTimer = chip("", v -> pickTimer());
        btnDisplay = chip("", v -> pickDisplay());
        root.addView(pair(btnTimer, btnDisplay));

        // Resend
        Button resend = smallButton("📡 ارسال مجدد وضعیت فعلی", v -> send());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        lp.topMargin = dp(20);
        root.addView(resend, lp);

        return scroll;
    }

    // ----------------------------------------------------------- actions

    private void changeTemp(int d) {
        int t = ac.temp + d;
        if (t < GreeProtocol.MIN_TEMP || t > GreeProtocol.MAX_TEMP) {
            toast("محدوده دما " + fa(GreeProtocol.MIN_TEMP) + " تا " + fa(GreeProtocol.MAX_TEMP) + " درجه است");
            return;
        }
        ac.temp = t;
        apply();
    }

    private void pickSwingV() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("جهت باد عمودی")
                .setSingleChoiceItems(SWV_NAMES, indexOf(SWV_VALUES, ac.swingV), (d, w) -> {
                    ac.swingV = SWV_VALUES[w];
                    d.dismiss();
                    apply();
                }).show();
    }

    private void pickSwingH() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("جهت باد افقی")
                .setSingleChoiceItems(SWH_NAMES, indexOf(SWH_VALUES, ac.swingH), (d, w) -> {
                    ac.swingH = SWH_VALUES[w];
                    d.dismiss();
                    apply();
                }).show();
    }

    private void pickTimer() {
        final String[] items = new String[49];
        items[0] = "خاموش";
        for (int i = 1; i <= 48; i++) items[i] = timerLabel(i * 30);
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle(ac.power ? "تایمر خاموش‌شدن" : "تایمر روشن‌شدن")
                .setSingleChoiceItems(items, ac.timerMinutes / 30, (d, w) -> {
                    ac.timerMinutes = w * 30;
                    d.dismiss();
                    apply();
                }).show();
    }

    private void pickDisplay() {
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("دمای نمایش‌داده‌شده روی پنل")
                .setSingleChoiceItems(DISP_NAMES, ac.display, (d, w) -> {
                    ac.display = w;
                    d.dismiss();
                    apply();
                }).show();
    }

    private void showSettings() {
        String[] models = {"YAW1F / YB1FA (رایج‌ترین)", "YBOF / سایر مدل‌ها"};
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("مدل ریموت اصلی")
                .setSingleChoiceItems(models, ac.modelYaw1f ? 0 : 1, (d, w) -> {
                    ac.modelYaw1f = (w == 0);
                    d.dismiss();
                    saveState();
                    toast("اگر کولر به فرمان‌ها واکنش نداد، مدل دیگر را امتحان کنید");
                })
                .setNegativeButton("بستن", null)
                .show();
    }

    private void apply() {
        refresh();
        saveState();
        send();
    }

    private void send() {
        if (displayCard != null) displayCard.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        if (ir == null || !ir.hasIrEmitter()) {
            toast("فرستنده مادون قرمز (IR) روی این گوشی پیدا نشد");
            return;
        }
        try {
            ir.transmit(GreeProtocol.FREQ, ac.toPattern());
            tvIr.setText("📡 ارسال شد: " + GreeProtocol.hex(ac.toBytes()));
        } catch (Exception e) {
            toast("خطا در ارسال IR: " + e.getMessage());
        }
    }

    // ----------------------------------------------------------- refresh

    private void refresh() {
        boolean on = ac.power;
        int modeColor = ac.mode == GreeProtocol.MODE_HEAT ? HEAT : ACCENT;

        btnPower.setBackground(round(on ? ON_GREEN : OFF_RED, 18));
        tvTemp.setText(ac.mode == GreeProtocol.MODE_FAN ? "--" : fa(ac.temp) + "°");
        tvTemp.setTextColor(on ? TEXT : MUTED);
        tvMode.setText(on ? MODE_ICONS[ac.mode] + "  " + MODE_NAMES[ac.mode] : "خاموش");
        tvMode.setTextColor(on ? modeColor : OFF_RED);

        int effFan = ac.mode == GreeProtocol.MODE_DRY ? GreeProtocol.FAN_LOW : ac.fan;
        String status = "فن: " + FAN_NAMES[effFan] + "   •   عمودی: " + SWV_NAMES[indexOf(SWV_VALUES, ac.swingV)];
        if (ac.swingH != GreeProtocol.SWH_OFF) status += "\nافقی: " + SWH_NAMES[indexOf(SWH_VALUES, ac.swingH)];
        if (ac.timerMinutes > 0)
            status += "\n⏱ " + (on ? "خاموش" : "روشن") + " شدن بعد از " + timerLabel(ac.timerMinutes);
        tvStatus.setText(status);

        StringBuilder fl = new StringBuilder();
        if (ac.turbo) fl.append("توربو  ");
        if (ac.sleep) fl.append("خواب  ");
        if (ac.xfan) fl.append("X-Fan  ");
        if (ac.econo) fl.append("صرفه‌جویی  ");
        if (ac.iFeel) fl.append("I-Feel  ");
        if (!ac.light) fl.append("چراغ خاموش");
        tvFlags.setText(fl.toString().trim());

        for (int i = 0; i < 5; i++) setActive(modeBtns[i], ac.mode == i, i == 4 ? HEAT : ACCENT);
        for (Button b : fanBtns) b.setEnabled(ac.mode != GreeProtocol.MODE_DRY);
        for (int i = 0; i < 4; i++) setActive(fanBtns[i], ac.fan == i, ACCENT);

        btnSwingV.setText("↕ عمودی\n" + SWV_NAMES[indexOf(SWV_VALUES, ac.swingV)]);
        btnSwingH.setText("↔ افقی\n" + SWH_NAMES[indexOf(SWH_VALUES, ac.swingH)]);
        setActive(btnSwingV, ac.swingV != GreeProtocol.SWV_LAST, ACCENT);
        setActive(btnSwingH, ac.swingH != GreeProtocol.SWH_OFF, ACCENT);

        setActive(tTurbo, ac.turbo, ACCENT);
        setActive(tSleep, ac.sleep, ACCENT);
        setActive(tLight, ac.light, ACCENT);
        setActive(tXfan, ac.xfan, ACCENT);
        setActive(tEcono, ac.econo, ON_GREEN);
        setActive(tIfeel, ac.iFeel, ACCENT);

        btnTimer.setText("⏱ تایمر\n" + (ac.timerMinutes == 0 ? "خاموش" : timerLabel(ac.timerMinutes)));
        setActive(btnTimer, ac.timerMinutes > 0, ACCENT);
        btnDisplay.setText("🖥 نمایش دما\n" + DISP_NAMES[ac.display]);
        setActive(btnDisplay, false, ACCENT);

        if (ir == null || !ir.hasIrEmitter()) {
            tvIr.setText("⚠ فرستنده IR شناسایی نشد");
            tvIr.setTextColor(OFF_RED);
        } else if (tvIr.getText().length() == 0) {
            tvIr.setText("✓ فرستنده IR آماده است — گوشی را به سمت کولر بگیرید");
            tvIr.setTextColor(MUTED);
        }
    }

    // ----------------------------------------------------------- persistence

    private void loadState() {
        ac.power = prefs.getBoolean("power", false);
        ac.mode = prefs.getInt("mode", GreeProtocol.MODE_COOL);
        ac.temp = prefs.getInt("temp", 24);
        ac.fan = prefs.getInt("fan", GreeProtocol.FAN_AUTO);
        ac.swingV = prefs.getInt("swingV", GreeProtocol.SWV_AUTO);
        ac.swingH = prefs.getInt("swingH", GreeProtocol.SWH_OFF);
        ac.turbo = prefs.getBoolean("turbo", false);
        ac.sleep = prefs.getBoolean("sleep", false);
        ac.light = prefs.getBoolean("light", true);
        ac.xfan = prefs.getBoolean("xfan", false);
        ac.econo = prefs.getBoolean("econo", false);
        ac.iFeel = prefs.getBoolean("ifeel", false);
        ac.display = prefs.getInt("display", GreeProtocol.DISP_SET);
        ac.timerMinutes = prefs.getInt("timer", 0);
        ac.modelYaw1f = prefs.getBoolean("yaw1f", true);
    }

    private void saveState() {
        prefs.edit()
                .putBoolean("power", ac.power).putInt("mode", ac.mode).putInt("temp", ac.temp)
                .putInt("fan", ac.fan).putInt("swingV", ac.swingV).putInt("swingH", ac.swingH)
                .putBoolean("turbo", ac.turbo).putBoolean("sleep", ac.sleep).putBoolean("light", ac.light)
                .putBoolean("xfan", ac.xfan).putBoolean("econo", ac.econo).putBoolean("ifeel", ac.iFeel)
                .putInt("display", ac.display).putInt("timer", ac.timerMinutes)
                .putBoolean("yaw1f", ac.modelYaw1f)
                .apply();
    }

    // ----------------------------------------------------------- helpers

    private static int indexOf(int[] arr, int v) {
        for (int i = 0; i < arr.length; i++) if (arr[i] == v) return i;
        return 0;
    }

    private static String fa(int n) {
        String s = String.valueOf(n);
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) sb.append(c >= '0' && c <= '9' ? (char) ('۰' + (c - '0')) : c);
        return sb.toString();
    }

    private static String timerLabel(int mins) {
        int h = mins / 60;
        boolean half = mins % 60 >= 30;
        if (h == 0) return "نیم ساعت";
        return fa(h) + (half ? "/۵" : "") + " ساعت";
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void setActive(Button b, boolean active, int color) {
        GradientDrawable g = round(active ? color : BTN, 14);
        if (!active) g.setStroke(dp(1), 0xFF33414E);
        b.setBackground(g);
        b.setTextColor(active ? Color.WHITE : TEXT);
        b.setAlpha(b.isEnabled() ? 1f : 0.4f);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView section(String s) {
        TextView t = text(s, 13, MUTED, true);
        t.setPadding(dp(4), dp(18), dp(4), dp(8));
        return t;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private LinearLayout pair(View a, View b) {
        LinearLayout r = row();
        r.setPadding(0, 0, 0, dp(8));
        r.addView(a, weighted(1, dp(60)));
        r.addView(spacer(8));
        r.addView(b, weighted(1, dp(60)));
        return r;
    }

    private View spacer(int dpW) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(dpW), 1));
        return v;
    }

    private LinearLayout.LayoutParams weighted(float w, int h) {
        return new LinearLayout.LayoutParams(0, h, w);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private Button baseButton(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setStateListAnimator(null);
        b.setPadding(dp(4), dp(2), dp(4), dp(2));
        b.setOnClickListener(l);
        return b;
    }

    private Button bigButton(String label, View.OnClickListener l) {
        Button b = baseButton(label, l);
        b.setTextSize(32);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(round(BTN, 18));
        return b;
    }

    private Button chip(String label, View.OnClickListener l) {
        Button b = baseButton(label, l);
        b.setTextSize(13);
        b.setBackground(round(BTN, 14));
        return b;
    }

    private Button smallButton(String label, View.OnClickListener l) {
        Button b = baseButton(label, l);
        b.setTextSize(15);
        b.setBackground(round(BTN, 14));
        return b;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
