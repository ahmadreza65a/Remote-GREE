# Store listing text

## Persian (fa-IR)
عنوان: ریموت اسپیلت – کنترل کولر گازی با IR
توضیح کوتاه: ریموت کامل کولر گازی با فرستنده مادون قرمز گوشی، سازگار با پروتکل Gree
توضیح کامل:
با این برنامه، گوشی شما به ریموت کامل کولر گازی تبدیل می‌شود.
• روشن/خاموش و تنظیم دما با صفحه دایره‌ای (۱۶ تا ۳۰ درجه)
• حالت‌های سرمایش، گرمایش، خشک‌کن، فن و خودکار
• سرعت فن: خودکار، کم، متوسط، زیاد
• تنظیم مستقیم جهت باد عمودی و افقی و حالت‌های نوسان
• توربو، خواب، چراغ پنل، X-Fan، صرفه‌جویی انرژی، I-Feel
• تایمر روشن/خاموش تا ۲۴ ساعت
• بدون تبلیغات، بدون اینترنت، بدون جمع‌آوری اطلاعات
نیازمند گوشی دارای فرستنده مادون قرمز (IR Blaster).
این برنامه محصول رسمی Gree نیست.

## English (en-US)
Title: Split Remote – IR AC Remote
Short: Full infrared remote for split air conditioners (Gree IR protocol compatible)
Full: Turn your IR-blaster phone into a complete AC remote: power, 16–30 °C dial, cool/heat/dry/fan/auto,
fan speed, vertical & horizontal air direction, turbo, sleep, light, X-Fan, eco, I-Feel and on/off timer.
No ads, no internet, no data collection. Requires a phone with an IR blaster. Not affiliated with Gree.
